<!--
Thank you for reporting an issue.
Before you submit your issue, please provide the following information as much as possible.
-->

## 🐥环境 & 设置

**Node.js & npm version**

```bash

```

**Your site `_config.yml`** (Optional)

```yml

```

**Your theme `_config.yml`** (Optional)

```yml

```

**Your browsers** (Optional)

> The browser you use

**Your OSes** (Optional)

> what platforms (operating systems and devices) are affected?

Your package.json `package.json`:

```json

```

## For BUG

<!--
 1. BUG description
 2. The way to reproduce
-->

## ❓问题

<!-- 问题描述 -->

## For feature request

<!-- Feature description -->
